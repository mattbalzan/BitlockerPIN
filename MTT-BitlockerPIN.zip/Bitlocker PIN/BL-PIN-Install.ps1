﻿# --| Create Scheduled Task to prompt user to enter Bitlocker PIN
# --| Script will copy all the binaries to "C:\Program Files\BL-PIN" and create the sched task.
# --| Troubleshooting log (PIN.log) is created in the above folder. 
# --| M.Balzan (CE) 01/10/2020
# --| Version 1.0 | Original
# --| Version 1.1 | Added UseEnhancedPIN reg entry for Popup call & set Sched task trigger to Startup
# --| Version 1.2 | Added 10 minute -ExecutionTimeLimit to the settings to help compensate the login process.

# --| Create binaries folder if not found.
if(!(Test-Path "C:\Program Files\BL-PIN")) {New-Item -Path "C:\Program Files\BL-PIN" -ItemType Directory -Force}

Start-Transcript "C:\Program Files\BL-PIN\PIN.log"

# --| Copy all binaries to PIN folder
Copy-Item -Path $PSScriptRoot\* -Destination "C:\Program Files\BL-PIN" -Force 

# --| Set UseEnhancedPIN 
reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\FVE" /v UseEnhancedPin /t REG_DWORD /d 1 /f | Out-Host

# --| Create schedule task to launch user PIN pop-up
$SchTaskNameMap = "BitlockerPIN"
$ARGS = '-NoProfile -WindowStyle Hidden -Ex bypass -file "C:\Program Files\BL-PIN\SetBitLockerPin.ps1"'
$SchTaskLogonAction = New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument ($ARGS)
$SchTaskPrin = New-ScheduledTaskPrincipal -UserId "SYSTEM" -RunLevel Highest
$SchTaskTrig =  New-ScheduledTaskTrigger -AtLogOn
$SchTaskSett = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 10) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -Action $SchTaskLogonAction -Trigger $SchTaskTrig -Settings $SchTaskSett -Principal $SchTaskPrin -TaskName $SchTaskNameMap -Description "Launch pop-up to prompt users to enter their Bitlocker PIN."

Stop-Transcript 