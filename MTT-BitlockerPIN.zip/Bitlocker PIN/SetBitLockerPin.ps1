# Author: Oliver Kieselbach (oliverkieselbach.com)
# Date: 08/01/2019
# Description: Starts the Windows Forms Dialog for BitLocker PIN entry and receives the PIN via exit code to set the additional key protector
# - 10/21/2019 changed PIN handover
# - 02/10/2020 added content length check
# - 01/12/2020 added Set-Location to allow sched task to launch Popup.ps1 as system with ServiceUI.exe

# --| Set a condition for the Scheduled Task to be disabled if the PIN has been set - Matt Balzan (CE) 01/10/2020
 
# The script is provided "AS IS" with no warranties.

# --| If we are running as a 32-bit process on an x64 system, re-launch as a 64-bit process
if ("$env:PROCESSOR_ARCHITEW6432" -ne "ARM64")
{
    if (Test-Path "$($env:WINDIR)\SysNative\WindowsPowerShell\v1.0\powershell.exe")
    {
        & "$($env:WINDIR)\SysNative\WindowsPowerShell\v1.0\powershell.exe" -ExecutionPolicy bypass -NoProfile -File "$PSCommandPath"
        Exit $lastexitcode
    }
}

Start-Transcript -Path "C:\Program Files\BL-PIN\PIN.log" -Append

if($(Get-BitLockerVolume -MountPoint $env:SystemDrive).KeyProtector | Where { $_.KeyProtectorType -eq 'TpmPin' }){

Write-host "PIN already set - disabling Scheduled Task and closing script!"
Disable-ScheduledTask -TaskName BitlockerPIN
Exit 1
}
else {

$BLPath = "C:\Program Files\BL-PIN"

Set-Location $BLPATH -Verbose

.\ServiceUI.exe -process:Explorer.exe "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -WindowStyle Hidden -file .\Popup.ps1
$exitCode = $LASTEXITCODE

$pathPINFile = $(Join-Path -Path $([Environment]::GetFolderPath("CommonDocuments")) -ChildPath "PIN-prompted.txt")

If ($exitCode -eq 0 -And (Test-Path -Path $pathPINFile)) { 
    $encodedText = Get-Content -Path $pathPINFile
    if ($encodedText.Length -gt 0) {
        $PIN = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($encodedText))
        Add-BitLockerKeyProtector -MountPoint $env:SystemDrive -Pin $(ConvertTo-SecureString $PIN -AsPlainText -Force) -TpmAndPinProtector
    }
}

# Cleanup
Remove-Item -Path $pathPINFile -Force -ErrorAction SilentlyContinue
}

Stop-Transcript